'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { VirtualJoystick } from '@/components/virtual-joystick';
import { Button } from '@/components/ui/button';
import type { Player } from '@/lib/player';
import type { SoundState } from '@/lib/audio';
export default function Home() {
  const host=useRef<HTMLDivElement>(null);
  const controls=useRef<{reset:()=>void;input:(key:string,pressed:boolean)=>void;move:(x:number,z:number)=>void;view:()=>void;toggleMusic:()=>void;toggleSfx:()=>void}|null>(null);
  const moveJoystick=useCallback((x:number,z:number)=>controls.current?.move(x,z),[]);
  const [status,setStatus]=useState('正在准备小岛'),[loaded,setLoaded]=useState(false),[error,setError]=useState(''),[portrait,setPortrait]=useState(false);
  const [player,setPlayer]=useState<Player|null>(null),[sound,setSound]=useState<SoundState>({music:true,sfx:true,playing:false,error:false}),[pickup,setPickup]=useState(0);
  useEffect(()=>{let stop:(()=>void)|undefined;let cancelled=false;
    import('@/lib/game').then(async({createGame})=>{if(cancelled||!host.current)return;
      const game=await createGame(host.current,{ready:()=>{setLoaded(true);setStatus('自由漫游');},status:setStatus,error:setError,player:setPlayer,sound:setSound,collect:()=>setPickup(n=>n+1)});
      if(cancelled)game.dispose();else{controls.current=game;stop=game.dispose;}
    }).catch(e=>setError(`场景未能加载：${e.message}`));
    return()=>{cancelled=true;stop?.();controls.current=null;};
  },[]);
  const touch=(key:string)=>({onContextMenu:(e:React.MouseEvent)=>e.preventDefault(),onPointerDown:(e:React.PointerEvent<HTMLButtonElement>)=>{e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);controls.current?.input(key,true);},onPointerUp:()=>controls.current?.input(key,false),onPointerCancel:()=>controls.current?.input(key,false),onLostPointerCapture:()=>controls.current?.input(key,false)});
  return <main className="game-shell"><div ref={host} className="viewport" aria-label="LuckyLob 三维游戏。WASD 或方向键移动，空格跳跃。"/>
    <header className="hud top-hud"><div className="brand"><span className="brand-icon">A</span><div><strong>LUCKYLOB</strong><span>小岛漫游 <i/> 3D PLAYGROUND</span></div></div><div className="top-actions"><Button className="hud-button" variant="ghost" onClick={()=>{setPortrait(!portrait);controls.current?.view();}}>{portrait?'返回漫游':'近看小人'}</Button><Button className="hud-button" variant="ghost" onClick={()=>{controls.current?.reset();setPortrait(false);}}>回到起点 ↺</Button></div></header>
    {!loaded&&!error&&<div className="loading" role="status"><span className="loader"/><strong>LuckyLob 正在上岛</strong><span>加载角色和动作…</span></div>}
    {error&&<div className="loading error" role="alert"><strong>小岛暂时未能打开</strong><span>{error}</span><Button onClick={()=>window.location.reload()}>重新加载</Button></div>}
    <div className="hud wallet"><div className="wallet-top"><span className="coin-symbol">L</span><span>算力金币</span></div><div className="balance" aria-live="polite"><strong>{player?.lob.toLocaleString()??'0'}</strong><span>LOB</span></div><span className="player-id">ID · {player?.id??'准备中'}</span><span className="wallet-note">{player?.persistent===false?'暂存于本次游戏':'本机试玩余额 · 自动保存'}</span><span className="pickup-hint">触碰金币 +1 LOB</span></div>
    {pickup>0&&<div key={pickup} className="pickup-toast" aria-hidden="true">+1 <span>LOB</span></div>}
    <div className="hud sound-controls"><div className="sound-buttons"><Button className="hud-button" aria-pressed={sound.music} onClick={()=>controls.current?.toggleMusic()}>{sound.music?'♫ 音乐开':'♫ 音乐关'}</Button><Button className="hud-button" aria-pressed={sound.sfx} onClick={()=>controls.current?.toggleSfx()}>{sound.sfx?'♪ 音效开':'♪ 音效关'}</Button></div><span className="track-label">{sound.error?'音乐加载失败，请刷新重试':sound.playing?'Neon Dice Parade':sound.music?'点击场景或按键开始音乐':'背景音乐已暂停'}</span></div>
    <footer className="hud bottom-hud"><div className="instructions"><span><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> / 方向键 <b>移动</b></span><span><kbd className="space">SPACE</kbd><b>跳跃</b></span><span className="camera-hint">拖动旋转视角 · 滚轮缩放</span></div><div className="state-pill"><i/>{status}</div></footer>
    <div className="touch-controls" aria-label="触屏操作"><div className="touch-move"><span className="touch-hint">拖动摇杆 · 松手停止</span><VirtualJoystick onMove={moveJoystick}/></div><div className="touch-jump"><span className="touch-hint">拖动视角 · 双指缩放</span><button className="jump-touch" aria-label="跳跃" {...touch('Space')}>↑<span>跳跃</span></button></div></div>
  </main>;
}
