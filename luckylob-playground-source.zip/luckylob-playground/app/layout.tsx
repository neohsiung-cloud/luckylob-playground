import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata:Metadata={title:'LuckyLob · 小岛漫游',description:'在三维小岛上操控 LuckyLob 自由走路、跳跃。支持键盘和触屏。'};
export const viewport:Viewport={width:'device-width',initialScale:1,viewportFit:'cover',themeColor:'#cee8ed'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="zh-CN"><body>{children}</body></html>;}
