'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import {joystickVector} from '@/lib/joystick';

export function VirtualJoystick({onMove}:{onMove:(x:number,z:number)=>void}){
  const pointer=useRef<number|null>(null),origin=useRef({x:0,y:0,radius:1});
  const [thumb,setThumb]=useState({x:0,y:0,active:false});
  const stop=useCallback(()=>{pointer.current=null;setThumb({x:0,y:0,active:false});onMove(0,0);},[onMove]);
  useEffect(()=>{const hide=()=>{if(document.hidden)stop();};window.addEventListener('blur',stop);window.addEventListener('resize',stop);document.addEventListener('visibilitychange',hide);return()=>{window.removeEventListener('blur',stop);window.removeEventListener('resize',stop);document.removeEventListener('visibilitychange',hide);onMove(0,0);};},[stop,onMove]);
  const update=(e:React.PointerEvent<HTMLDivElement>)=>{const v=joystickVector(e.clientX-origin.current.x,e.clientY-origin.current.y,origin.current.radius);setThumb({x:v.thumbX,y:v.thumbY,active:true});onMove(v.x,v.z);};
  return <div className={`joystick${thumb.active?' is-active':''}`} role="group" aria-label="圆形移动摇杆，拖动控制方向，松手停止" onContextMenu={e=>e.preventDefault()}
    onPointerDown={e=>{if(pointer.current!==null)return;e.preventDefault();pointer.current=e.pointerId;const r=e.currentTarget.getBoundingClientRect();origin.current={x:r.left+r.width/2,y:r.top+r.height/2,radius:r.width/2-34};e.currentTarget.setPointerCapture(e.pointerId);update(e);}}
    onPointerMove={e=>{if(pointer.current===e.pointerId){e.preventDefault();update(e);}}}
    onPointerUp={e=>{if(pointer.current===e.pointerId)stop();}}
    onPointerCancel={e=>{if(pointer.current===e.pointerId)stop();}}
    onLostPointerCapture={e=>{if(pointer.current===e.pointerId)stop();}}>
    <span className="joystick-ring" aria-hidden="true"/><span className="joystick-north" aria-hidden="true">⌃</span><span className="joystick-south" aria-hidden="true">⌄</span><span className="joystick-west" aria-hidden="true">‹</span><span className="joystick-east" aria-hidden="true">›</span>
    <span className="joystick-thumb" aria-hidden="true" style={{transform:`translate(${thumb.x}px,${thumb.y}px)`}}><span/></span>
  </div>;
}
