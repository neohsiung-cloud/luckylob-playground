import * as T from 'three';
// Floor coins follow walkable paths. Three extras sit on the jump platforms.
export const COIN_POSITIONS=[[-.12,.73,0],[-.24,.73,-1],[-.36,.73,-2],[-.48,.73,-3],[-.6,.73,-4],[.3,.73,-5.3],[1.4,.73,-6.1],[-2,.73,1.2],[-3.4,.73,1.4],[-4.5,.73,.7],[-4.2,.73,-1.3],[-2.3,.73,-2.7],[1.8,.73,1.9],[3.1,.73,2.4],[4.5,.73,2],[5.6,.73,.4],[6.6,.73,-1.2],[3.8,1.15,-2.7],[5.6,1.53,-4.2],[3.6,1.91,-5.8]];
export function canCollect(player:{x:number;y:number;z:number},coin:{x:number;y:number;z:number}){return Math.hypot(player.x-coin.x,player.z-coin.z)<.54&&coin.y>=player.y+.10&&coin.y<=player.y+1.55;}
export function createCoinField(scene:T.Scene,onCollect:()=>void){
  const gold=new T.MeshStandardMaterial({color:'#ffca35',metalness:.65,roughness:.27,emissive:'#a96900',emissiveIntensity:.2});
  const edge=new T.MeshStandardMaterial({color:'#ffed96',metalness:.55,roughness:.24});
  const canvas=document.createElement('canvas');canvas.width=256;canvas.height=256;const ctx=canvas.getContext('2d')!;
  ctx.clearRect(0,0,256,256);ctx.strokeStyle='#774211';ctx.lineWidth=7;ctx.beginPath();ctx.arc(128,128,109,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#774211';ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='900 78px Arial';ctx.fillText('LOB',128,135);
  const texture=new T.CanvasTexture(canvas);texture.colorSpace=T.SRGBColorSpace;const stamp=new T.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false});
  const bodyGeo=new T.CylinderGeometry(.28,.28,.085,40),rimGeo=new T.TorusGeometry(.258,.021,7,40),faceGeo=new T.PlaneGeometry(.49,.49);
  const coins=COIN_POSITIONS.map(([x,y,z],i)=>{const group=new T.Group();const body=new T.Mesh(bodyGeo,gold);body.rotation.x=Math.PI/2;body.castShadow=true;group.add(body);
    for(const sign of [-1,1]){const rim=new T.Mesh(rimGeo,edge);rim.position.z=sign*.045;group.add(rim);const label=new T.Mesh(faceGeo,stamp);label.position.z=sign*.047;if(sign<0)label.rotation.y=Math.PI;group.add(label);}
    group.position.set(x,y,z);scene.add(group);return{group,x,y,z,readyAt:0,phase:i*.71};});
  const sparks:{mesh:T.Mesh;velocity:T.Vector3;life:number}[]=[];const sparkGeo=new T.IcosahedronGeometry(.04,0);let count=0;
  function collect(player:T.Vector3,time:number){for(const coin of coins){if(!coin.group.visible||!canCollect(player,coin.group.position))continue;coin.readyAt=time+24;coin.group.visible=false;count++;onCollect();for(let j=0;j<7;j++){const mesh=new T.Mesh(sparkGeo,edge);mesh.position.copy(coin.group.position);scene.add(mesh);sparks.push({mesh,velocity:new T.Vector3(Math.cos(j)*.65,1.2+Math.sin(j)*.2,Math.sin(j)*.65),life:.55});}}}
  function update(time:number,dt:number){for(const c of coins){if(!c.group.visible&&time>=c.readyAt)c.group.visible=true;if(c.group.visible){c.group.position.y=c.y+Math.sin(time*2.5+c.phase)*.07;c.group.rotation.y=time*1.5+c.phase;}}
    for(let i=sparks.length-1;i>=0;i--){const s=sparks[i];s.life-=dt;s.velocity.y-=3*dt;s.mesh.position.addScaledVector(s.velocity,dt);s.mesh.scale.setScalar(Math.max(0,s.life/.55));if(s.life<=0){scene.remove(s.mesh);sparks.splice(i,1);}}}
  return{collect,update,count:()=>count,active:()=>coins.filter(c=>c.group.visible).length,dispose:()=>{coins.forEach(c=>scene.remove(c.group));sparks.forEach(s=>scene.remove(s.mesh));[bodyGeo,rimGeo,faceGeo,sparkGeo].forEach(g=>g.dispose());[gold,edge,stamp].forEach(m=>m.dispose());texture.dispose();}};
}
