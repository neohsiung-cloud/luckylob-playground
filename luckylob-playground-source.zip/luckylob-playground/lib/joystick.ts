/** Radial dead zone and circular clamp keep diagonal speed equal to axial speed. */
export function joystickVector(dx:number,dy:number,radius:number){
  const length=Math.hypot(dx,dy),safeRadius=Math.max(1,radius);
  const amount=Math.min(length/safeRadius,1),speed=Math.max(0,(amount-.13)/.87);
  return {x:length?dx/length*speed:0,z:length?dy/length*speed:0,
    thumbX:length?dx/length*Math.min(length,safeRadius):0,thumbY:length?dy/length*Math.min(length,safeRadius):0};
}
