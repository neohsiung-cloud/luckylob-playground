export type SoundState={music:boolean;sfx:boolean;playing:boolean;error:boolean};
export function createSound(onChange:(state:SoundState)=>void){
  const music=new Audio('/audio/neon-dice-parade.mp3');music.loop=true;music.volume=.24;music.preload='auto';
  let context:AudioContext|undefined,unlocked=false,disposed=false;
  let state:SoundState={music:true,sfx:true,playing:false,error:false};
  try{const saved=JSON.parse(localStorage.getItem('luckylob.sound.v1')||'null');if(saved){state.music=saved.music!==false;state.sfx=saved.sfx!==false;}}catch{}
  const publish=()=>{if(!disposed)onChange({...state});};
  const persist=()=>{try{localStorage.setItem('luckylob.sound.v1',JSON.stringify({music:state.music,sfx:state.sfx}));}catch{}publish();};
  const playMusic=()=>{if(!disposed&&state.music&&unlocked&&!document.hidden){void music.play().then(()=>{state.playing=true;state.error=false;publish();}).catch(()=>{state.playing=false;publish();});}};
  function unlock(){if(disposed)return;unlocked=true;if(state.sfx){context??=new AudioContext();if(context.state==='suspended')void context.resume();}if(music.paused)playMusic();}
  const visibility=()=>{if(document.hidden){music.pause();state.playing=false;void context?.suspend();publish();}else if(unlocked){void context?.resume();playMusic();}};
  music.addEventListener('error',()=>{state.error=true;state.playing=false;publish();});
  window.addEventListener('pointerdown',unlock,{capture:true});window.addEventListener('keydown',unlock,{capture:true});document.addEventListener('visibilitychange',visibility);publish();
  function tone(start:number,end:number,offset:number,duration:number,type:OscillatorType,volume:number){if(!state.sfx||!context||context.state!=='running')return;const time=context.currentTime+offset,osc=context.createOscillator(),gain=context.createGain();osc.type=type;osc.frequency.setValueAtTime(start,time);osc.frequency.exponentialRampToValueAtTime(end,time+duration);gain.gain.setValueAtTime(.0001,time);gain.gain.exponentialRampToValueAtTime(volume,time+.008);gain.gain.exponentialRampToValueAtTime(.0001,time+duration);osc.connect(gain);gain.connect(context.destination);osc.start(time);osc.stop(time+duration+.015);osc.onended=()=>{osc.disconnect();gain.disconnect();};}
  function jump(){tone(190,690,0,.14,'square',.07);tone(390,830,.04,.14,'triangle',.07);}
  function coin(){tone(950,950,0,.065,'square',.065);tone(1425,1425,.065,.19,'square',.055);}
  function toggleMusic(){state.music=!state.music;if(state.music)unlock();else{music.pause();state.playing=false;}persist();}
  function toggleSfx(){state.sfx=!state.sfx;if(state.sfx)unlock();persist();}
  return{jump,coin,toggleMusic,toggleSfx,snapshot:()=>({...state}),dispose:()=>{disposed=true;music.pause();music.src='';void context?.close();window.removeEventListener('pointerdown',unlock,{capture:true});window.removeEventListener('keydown',unlock,{capture:true});document.removeEventListener('visibilitychange',visibility);}};
}
