import * as T from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { createSound, type SoundState } from './audio';
import { createPlayer, type Player } from './player';
import { createCoinField } from './coins';
type Hooks={ready:()=>void;status:(s:string)=>void;error:(s:string)=>void;player:(p:Player)=>void;sound:(s:SoundState)=>void;collect:()=>void};
type Platform={x:number;z:number;radius:number;top:number};
export async function createGame(host:HTMLDivElement,hooks:Hooks){
  const scene=new T.Scene();scene.background=new T.Color('#cee8ed');scene.fog=new T.Fog('#cee8ed',30,80);
  const renderer=new T.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
  const mobile=matchMedia('(pointer: coarse)').matches;renderer.setPixelRatio(Math.min(devicePixelRatio,mobile?1.35:1.75));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFShadowMap;
  renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;host.appendChild(renderer.domElement);renderer.domElement.tabIndex=0;
  const camera=new T.PerspectiveCamera(42,1,.1,120);scene.add(new T.HemisphereLight('#f1fcff','#769b7d',1.8));
  const sun=new T.DirectionalLight('#fff0d2',2.8);sun.position.set(-7,13,7);sun.castShadow=true;sun.shadow.mapSize.set(mobile?1024:2048,mobile?1024:2048);
  Object.assign(sun.shadow.camera,{left:-16,right:16,top:16,bottom:-16,near:.5,far:45});sun.shadow.bias=-.0003;sun.shadow.normalBias=.02;scene.add(sun);
  const material=(color:string,roughness=.85)=>new T.MeshStandardMaterial({color,roughness});
  const grass=material('#77b879'),sand=material('#e4c88f'),stone=material('#edf0d3'),trunk=material('#96734c');
  function add(geo:T.BufferGeometry,mat:T.Material,x:number,y:number,z:number){const m=new T.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);return m;}
  const water=add(new T.PlaneGeometry(180,180),material('#6cbfc4',.4),0,-.74,0);water.rotation.x=-Math.PI/2;water.castShadow=false;
  add(new T.CylinderGeometry(10.7,11.2,.8,96),sand,0,-.43,0);add(new T.CylinderGeometry(10.3,10.7,.24,96),grass,0,-.10,0);
  for(let i=0;i<10;i++){const p=add(new T.CylinderGeometry(.48,.48,.045,7),stone,Math.sin(i*.12)*3.1-1.2,.04,2.1-i*.73);p.rotation.y=i*.8;p.scale.z=.70;}
  const platforms:Platform[]=[{x:3.8,z:-2.7,radius:1.1,top:.42},{x:5.6,z:-4.2,radius:1,top:.80},{x:3.6,z:-5.8,radius:1.25,top:1.18}];
  const platformMat=material('#eddbb4');platforms.forEach(p=>{add(new T.CylinderGeometry(p.radius,p.radius+.07,p.top,48),platformMat,p.x,p.top/2,p.z);add(new T.CylinderGeometry(p.radius+.015,p.radius,.06,48),stone,p.x,p.top,p.z);});
  const obstacles:{x:number;z:number;r:number}[]=[];const leaves=[material('#3e956f'),material('#52a875'),material('#70b978')];
  function tree(x:number,z:number,h:number,i:number){add(new T.CylinderGeometry(.14,.20,h*.65,9),trunk,x,h*.32,z);const crown=add(new T.IcosahedronGeometry(h*.43,2),leaves[i%3],x,h*.85,z);crown.scale.set(.85,1.05,.82);obstacles.push({x,z,r:.3});}
  [[-5,-3,3.1],[-7,-.5,3.5],[-6,3,2.5],[.2,-7.7,3.5],[7,1,3.4],[6.3,4.3,2.6],[-3.6,-7,2.8]].forEach((a,i)=>tree(a[0],a[1],a[2],i));
  const flowerMat=material('#f8d58b'),flowerLeaf=material('#488969');
  for(let i=0;i<40;i++){const a=i*2.399,r=7.7+Math.sin(i*9),x=Math.cos(a)*r,z=Math.sin(a)*r;const rock=add(new T.IcosahedronGeometry(.13+(i%3)*.04,0),i%4===0?stone:flowerLeaf,x,.09,z);rock.scale.y=.6;if(i%3===0){add(new T.CylinderGeometry(.015,.015,.25,5),flowerLeaf,x,.16,z);add(new T.IcosahedronGeometry(.095,1),flowerMat,x,.32,z);}}
  const benchMat=material('#b98855');for(const x of [-3.8,-2.5])add(new T.BoxGeometry(.15,.48,.62),trunk,x,.24,-4.5);add(new T.BoxGeometry(1.65,.13,.7),benchMat,-3.15,.49,-4.5);add(new T.BoxGeometry(1.65,.39,.10),benchMat,-3.15,.88,-4.79);obstacles.push({x:-3.15,z:-4.5,r:.9});
  const sound=createSound(hooks.sound),player=createPlayer(hooks.player);
  const coins=createCoinField(scene,()=>{sound.coin();void player.award();hooks.collect();});let gameTime=0;
  const keys=new Set<string>(),pressedAt=new Map<string,number>(),releaseAt=new Map<string,number>(),position=new T.Vector3(0,.04,1),analog={x:0,z:0};let vy=0,grounded=true,jumpQueued=false;
  let character:T.Group|undefined,mixer:T.AnimationMixer|undefined;const actions:Record<string,T.AnimationAction>={};let current='';
  let yaw=.12,pitch=.34,distance=8.3,portrait=false,drag=false,lastX=0,lastY=0,disposed=false,frame=0;
  let heading=0,moved=0,jumps=0,peak=.04;const target=new T.Vector3(0,1,1);let accumulator=0,status='',lastTime=performance.now();
  function input(key:string,pressed:boolean){if(pressed){if(key==='Space'&&!keys.has(key))jumpQueued=true;if(!keys.has(key))pressedAt.set(key,performance.now());releaseAt.delete(key);keys.add(key);}else if(pressedAt.has(key)&&key!=='Space'){releaseAt.set(key,Math.max(performance.now(),pressedAt.get(key)!+90));}else keys.delete(key);}
  function reset(){position.set(0,.04,1);vy=0;grounded=true;jumpQueued=false;analog.x=analog.z=0;keys.clear();pressedAt.clear();releaseAt.clear();yaw=.12;pitch=.34;distance=8.3;portrait=false;heading=0;target.copy(position).y+=1;renderer.domElement.focus();}
  function view(){portrait=!portrait;distance=portrait?4.3:8.3;pitch=portrait?.12:.34;yaw=portrait?heading+.25:.12;renderer.domElement.focus();}
  const relevant=new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowLeft','ArrowDown','ArrowRight','Space','KeyR']);
  const keydown=(e:KeyboardEvent)=>{if(!relevant.has(e.code))return;if((e.target as HTMLElement)?.closest('button,input'))return;e.preventDefault();if(e.code==='KeyR')reset();else input(e.code,true);};
  const pointers=new Map<number,{x:number;y:number}>();let pinchDistance=0;
  const fingerDistance=()=>{const p=[...pointers.values()];return p.length>=2?Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y):0;};
  const keyup=(e:KeyboardEvent)=>input(e.code,false),blur=()=>{keys.clear();pressedAt.clear();releaseAt.clear();analog.x=analog.z=0;jumpQueued=false;drag=false;pointers.clear();pinchDistance=0;};
  const visibility=()=>{if(document.hidden)blur();};document.addEventListener('visibilitychange',visibility);
  const down=(e:PointerEvent)=>{pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});drag=true;lastX=e.clientX;lastY=e.clientY;pinchDistance=fingerDistance();renderer.domElement.setPointerCapture(e.pointerId);renderer.domElement.focus();};
  const move=(e:PointerEvent)=>{if(!drag||!pointers.has(e.pointerId))return;pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size>=2){const next=fingerDistance();if(pinchDistance>0&&next>0)distance=T.MathUtils.clamp(distance*pinchDistance/next,3.7,15);pinchDistance=next;}else{yaw-=(e.clientX-lastX)*.006;pitch=T.MathUtils.clamp(pitch+(e.clientY-lastY)*.004,.12,1.05);}lastX=e.clientX;lastY=e.clientY;};
  const up=(e:PointerEvent)=>{pointers.delete(e.pointerId);drag=pointers.size>0;pinchDistance=fingerDistance();const p=pointers.values().next().value;if(p){lastX=p.x;lastY=p.y;}},wheel=(e:WheelEvent)=>{e.preventDefault();distance=T.MathUtils.clamp(distance+e.deltaY*.006,3.7,15);};
  const resize=()=>{const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();};const observer=new ResizeObserver(resize);observer.observe(host);resize();
  window.addEventListener('keydown',keydown);window.addEventListener('keyup',keyup);window.addEventListener('blur',blur);
  const canvas=renderer.domElement;canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);canvas.addEventListener('wheel',wheel,{passive:false});
  function play(name:string){if(current===name||!actions[name])return;const prev=actions[current];current=name;const next=actions[name];next.reset().setEffectiveWeight(1).play();next.fadeIn(.15);prev?.fadeOut(.15);}
  function step(dt:number){
    if(!character)return;for(const[key,at]of releaseAt)if(performance.now()>=at){keys.delete(key);pressedAt.delete(key);releaseAt.delete(key);}let x=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0),z=(keys.has('KeyS')||keys.has('ArrowDown')?1:0)-(keys.has('KeyW')||keys.has('ArrowUp')?1:0);
    if(!x&&!z){x=analog.x;z=analog.z;}const length=Math.hypot(x,z);if(length>1){x/=length;z/=length;}
    const dx=(x*Math.cos(yaw)+z*Math.sin(yaw))*2.5*dt,dz=(-x*Math.sin(yaw)+z*Math.cos(yaw))*2.5*dt,nx=position.x+dx,nz=position.z+dz;
    const block=obstacles.some(o=>Math.hypot(nx-o.x,nz-o.z)<o.r+.25)||platforms.some(p=>Math.hypot(nx-p.x,nz-p.z)<p.radius+.20&&position.y<p.top-.1);
    if(!block&&Math.hypot(nx,nz)<9.85){position.x=nx;position.z=nz;moved+=Math.hypot(dx,dz);}
    if(length)heading=Math.atan2(dx,dz);
    if(jumpQueued){if(grounded){vy=5.7;grounded=false;jumps++;play('Jump');sound.jump();}jumpQueued=false;}
    const prevY=position.y;vy-=13.8*dt;position.y+=vy*dt;let floor=.04;
    for(const p of platforms)if(Math.hypot(position.x-p.x,position.z-p.z)<p.radius+.08&&prevY>=p.top+.025)floor=Math.max(floor,p.top+.06);
    if(position.y<=floor&&vy<=0){position.y=floor;vy=0;grounded=true;}else grounded=false;
    peak=Math.max(peak,position.y);play(!grounded?'Jump':length?'Walk':'Idle');
    const nextStatus=!grounded?'跳跃中':length?'散步中':'自由漫游';if(nextStatus!==status){status=nextStatus;hooks.status(status);}
    character.position.copy(position);const diff=Math.atan2(Math.sin(heading-character.rotation.y),Math.cos(heading-character.rotation.y));character.rotation.y+=diff*Math.min(1,dt*13);mixer?.update(dt);
    gameTime+=dt;coins.update(gameTime,dt);coins.collect(position,gameTime);
  }
  const wantedTarget=new T.Vector3();function tick(){if(disposed)return;frame=requestAnimationFrame(tick);const now=performance.now(),elapsed=Math.min((now-lastTime)/1000,.10);lastTime=now;accumulator+=elapsed;while(accumulator>=1/60){step(1/60);accumulator-=1/60;}wantedTarget.copy(position);wantedTarget.y+=portrait?1.25:1;target.lerp(wantedTarget,1-Math.exp(-elapsed*7));camera.position.set(target.x+Math.sin(yaw)*Math.cos(pitch)*distance,target.y+Math.sin(pitch)*distance,target.z+Math.cos(yaw)*Math.cos(pitch)*distance);camera.lookAt(target);renderer.render(scene,camera);canvas.dataset.qa=JSON.stringify({position:position.toArray(),grounded,vy,moved,jumps,peak,animation:current,clips:Object.keys(actions),collected:coins.count(),activeCoins:coins.active(),player:player.snapshot(),sound:sound.snapshot()});}tick();
  try{const gltf=await new GLTFLoader().loadAsync('/models/luckylob.glb');if(!disposed){character=gltf.scene;scene.add(character);character.traverse(o=>{if(o instanceof T.Mesh){o.castShadow=true;o.receiveShadow=true;}});mixer=new T.AnimationMixer(character);gltf.animations.forEach(c=>{actions[c.name]=mixer!.clipAction(c);});if(actions.Jump){actions.Jump.setLoop(T.LoopOnce,1);actions.Jump.clampWhenFinished=true;}play('Idle');hooks.ready();}}catch(e){if(!disposed)hooks.error(e instanceof Error?e.message:'角色加载失败');}
  const debug=()=>({ready:!!character,position:position.toArray(),grounded,vy,moved,jumps,peak,animation:current,clips:Object.keys(actions),triangles:renderer.info.render.triangles,drawCalls:renderer.info.render.calls});(window as unknown as {luckyState:()=>ReturnType<typeof debug>}).luckyState=debug;
  function dispose(){disposed=true;document.removeEventListener('visibilitychange',visibility);cancelAnimationFrame(frame);coins.dispose();sound.dispose();player.dispose();observer.disconnect();window.removeEventListener('keydown',keydown);window.removeEventListener('keyup',keyup);window.removeEventListener('blur',blur);canvas.removeEventListener('pointerdown',down);canvas.removeEventListener('pointermove',move);canvas.removeEventListener('pointerup',up);canvas.removeEventListener('pointercancel',up);canvas.removeEventListener('wheel',wheel);mixer?.stopAllAction();scene.traverse(o=>{if(o instanceof T.Mesh){o.geometry.dispose();const mats=Array.isArray(o.material)?o.material:[o.material];mats.forEach(m=>m.dispose());}});renderer.dispose();canvas.remove();}
  return{reset,input,move:(x:number,z:number)=>{analog.x=Number.isFinite(x)?T.MathUtils.clamp(x,-1,1):0;analog.z=Number.isFinite(z)?T.MathUtils.clamp(z,-1,1):0;},view,dispose,toggleMusic:sound.toggleMusic,toggleSfx:sound.toggleSfx};
}
