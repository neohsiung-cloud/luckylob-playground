export type Player = { id: string; lob: number; persistent: boolean };
const ID_KEY='luckylob.player.v1';
const BALANCE_PREFIX='luckylob.balance.v1.';
const validBalance=(raw:string|null)=>{const n=Number(raw);return Number.isSafeInteger(n)&&n>=0?n:0;};
export function createPlayer(onChange:(p:Player)=>void){
  let player:Player={id:`LOB-${crypto.randomUUID().slice(0,8).toUpperCase()}`,lob:0,persistent:true};
  try{const saved=localStorage.getItem(ID_KEY);if(saved&&/^LOB-[0-9A-F]{8}$/.test(saved))player.id=saved;else localStorage.setItem(ID_KEY,player.id);player.lob=validBalance(localStorage.getItem(BALANCE_PREFIX+player.id));}catch{player.persistent=false;}
  const publish=()=>onChange({...player});publish();
  const sync=(e:StorageEvent)=>{if(e.key===BALANCE_PREFIX+player.id){player.lob=validBalance(e.newValue);publish();}};window.addEventListener('storage',sync);
  async function award(){
    const increment=()=>{let previous=player.lob;if(player.persistent){try{previous=validBalance(localStorage.getItem(BALANCE_PREFIX+player.id));}catch{player.persistent=false;}}player.lob=Math.min(Number.MAX_SAFE_INTEGER,previous+1);if(player.persistent){try{localStorage.setItem(BALANCE_PREFIX+player.id,String(player.lob));}catch{player.persistent=false;}}publish();};
    if(navigator.locks){await navigator.locks.request('luckylob-lob-'+player.id,increment);}else increment();
  }
  return{award,snapshot:()=>({...player}),dispose:()=>window.removeEventListener('storage',sync)};
}
