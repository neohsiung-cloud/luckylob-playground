import {test} from 'node:test';
import assert from 'node:assert/strict';
import {joystickVector} from '../lib/joystick.ts';
test('center and small thumb jitter stop movement',()=>{assert.equal(joystickVector(0,0,40).x,0);assert.equal(joystickVector(3,2,40).z,0);});
test('full travel reaches unit speed and diagonals are capped',()=>{assert.equal(joystickVector(80,0,40).x,1);const v=joystickVector(80,-80,40);assert.ok(Math.abs(Math.hypot(v.x,v.z)-1)<1e-10);assert.ok(v.x>0&&v.z<0);assert.ok(Math.abs(Math.hypot(v.thumbX,v.thumbY)-40)<1e-10);});
test('partial travel provides proportional walking speed',()=>{const v=joystickVector(0,-20,40);assert.equal(v.x,0);assert.ok(v.z<0&&v.z>-.5);});
